# Changelog

## 1.0.9
- Moved Udon runtime to **Samples~**. Import sample to Assets to use the Area toggle.
- Editor tools remain as package assemblies. No UdonSharp dependency at package compile time.

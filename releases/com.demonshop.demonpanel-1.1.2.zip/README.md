# DemonPanel

Install via VCC or UPM. Import the **Udon Area Toggle** sample from Package Manager → Samples.
